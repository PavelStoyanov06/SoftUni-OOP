﻿namespace UniversityCompetition.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
