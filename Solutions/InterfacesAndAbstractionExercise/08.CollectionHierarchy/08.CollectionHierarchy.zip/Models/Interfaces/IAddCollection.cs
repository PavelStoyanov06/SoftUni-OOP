﻿namespace Models.Interfaces
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}
