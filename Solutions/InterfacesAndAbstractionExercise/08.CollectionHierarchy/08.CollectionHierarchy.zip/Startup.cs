﻿using CollectionHierarchy.Core;
using CollectionHierarchy.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();