﻿using ExplicitInterfaces.Core;
using ExplicitInterfaces.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();
