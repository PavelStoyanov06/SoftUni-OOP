﻿namespace FoodShortage.Models.Interfaces;

public interface INameable
{
    string Name { get; }
}
