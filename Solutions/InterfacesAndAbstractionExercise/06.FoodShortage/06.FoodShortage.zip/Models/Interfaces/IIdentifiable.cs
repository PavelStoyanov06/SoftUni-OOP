﻿namespace FoodShortage.Models.Interfaces;

public interface IIdentifiable
{
    string Id { get; }
}