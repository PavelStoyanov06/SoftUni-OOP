﻿namespace BirthdayCelebrations.Models.Interfaces;

public interface INameable
{
    string Name { get; }
}
