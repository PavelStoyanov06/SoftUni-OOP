﻿namespace BirthdayCelebrations.Models.Interfaces;

public interface IBirthable
{
    string Birthdate { get; }
}
