﻿namespace Raiding.IO.Interfaces;

public interface IWriter
{
    void WriteLine(string str);
}
